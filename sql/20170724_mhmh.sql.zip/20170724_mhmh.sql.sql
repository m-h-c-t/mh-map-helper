-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.7.19-0ubuntu0.16.04.1-log - (Ubuntu)
-- Server OS:                    Linux
-- HeidiSQL Version:             9.4.0.5174
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for mhmaphelper
CREATE DATABASE IF NOT EXISTS `mhmaphelper` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `mhmaphelper`;

-- Dumping structure for table mhmaphelper.cheeses
CREATE TABLE IF NOT EXISTS `cheeses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mhhh_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `mhhh_id` (`mhhh_id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.
-- Dumping structure for table mhmaphelper.locations
CREATE TABLE IF NOT EXISTS `locations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mhhh_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unik` (`name`),
  KEY `mhhh_id` (`mhhh_id`)
) ENGINE=InnoDB AUTO_INCREMENT=144 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.
-- Dumping structure for table mhmaphelper.mice
CREATE TABLE IF NOT EXISTS `mice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `wiki_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ht_id` int(10) unsigned DEFAULT NULL,
  `mhhh_id` int(10) unsigned DEFAULT NULL,
  `special` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `mhhh_id` (`mhhh_id`)
) ENGINE=InnoDB AUTO_INCREMENT=898 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.
-- Dumping structure for table mhmaphelper.setups
CREATE TABLE IF NOT EXISTS `setups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `mouse_id` int(10) unsigned NOT NULL DEFAULT '0',
  `location_id` int(10) unsigned NOT NULL,
  `stage_id` int(10) unsigned DEFAULT NULL,
  `cheese_id` int(10) unsigned NOT NULL,
  `ar` int(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_setup` (`mouse_id`,`location_id`,`stage_id`,`cheese_id`),
  KEY `fk_locations` (`location_id`),
  KEY `fk_cheeses` (`cheese_id`),
  KEY `fk_stages` (`stage_id`),
  CONSTRAINT `fk_cheeses` FOREIGN KEY (`cheese_id`) REFERENCES `cheeses` (`id`),
  CONSTRAINT `fk_locations` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `fk_mice` FOREIGN KEY (`mouse_id`) REFERENCES `mice` (`id`),
  CONSTRAINT `fk_stages` FOREIGN KEY (`stage_id`) REFERENCES `stages` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7113 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.
-- Dumping structure for table mhmaphelper.stages
CREATE TABLE IF NOT EXISTS `stages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(11) unsigned DEFAULT NULL,
  `mhhh_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_name` (`name`),
  KEY `mhhh_id` (`mhhh_id`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
